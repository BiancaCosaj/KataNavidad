

class SantaClaus
    def process(gift)
        return result_for_physical() if gift.is_a? :physical_product
        Result.new()
    end

       
    def result_for_physical
        result = Result.new()
        result.generate_for_shiping()
        result 
    end
end
