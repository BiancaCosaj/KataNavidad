

class Gifts
    def initialize(description)
        @description = description
    end

    def is_a? description
        @description == description
    end

end