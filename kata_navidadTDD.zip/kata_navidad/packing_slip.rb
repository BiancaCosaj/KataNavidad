

class PackingSlip
    def for_shiping?
         true
    end

    def duplicate
         PackingSlip.new()
    end

    def for_good?
         true
    end
    
    def is_active?
        true
    end
end



