

class Membership
    def is_active?
        true
    end

    def is_upgraded?
        true
    end

end