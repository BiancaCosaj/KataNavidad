require_relative '../santa_claus.rb'
require_relative '../packing_slip.rb'
require_relative '../gift.rb'
require_relative '../membership.rb'
require_relative '../result.rb'

#TDD Patrón null object


RSpec.describe"Santa's parsing a gift list" do
     before do
          @santa = SantaClaus.new()
     end

    it "If the gift is for a physical product, generate a packing slip for shipping" do
         #arrange
         gift = Gifts.new(:physical_products)
     
         #act
         result = @santa.process(gift)
 
         #assert
         expect(result.packing_slip.for_shiping?).to be true

         #arrange
         another_gift = Gift.new(:non_physical_product)

         #act
         result = @santa.process(another_gift)
 
         #assert
         expect(result.packing_slip.for_shiping?).to be false
    end 

    it " the gift is for a book, create a duplicate packing slip for the Good Children's department, since you know, good boys and girls read books..." do
          #arrange
          gift = Gifts.new(:book)
     
          #act
          result = @santa.process(gift)

          #assert
          expect(result.duplicate.for_good?).to be true     
    end
    it "If the gift is for a Netflix membership, activate that membership." do
          gift = Gifts.new(:netflix_membership)
          result = @santa.process(gift)

          expect(result.membership.is_active?).to be true
    end

    it "If the gift is an upgrade to a Netflix membership, apply the upgrade." do
          gift = Gifts.new(:netflix_membership_upgrade)
          result = @santa.process(gift)

          expect(result.membership.is_upgraded?).to be true
    end
 end
 
 
